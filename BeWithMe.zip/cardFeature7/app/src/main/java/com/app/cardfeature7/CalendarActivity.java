package com.app.cardfeature7;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.CircularProgressDrawable;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.harrywhewell.scrolldatepicker.DayScrollDatePicker;
import com.harrywhewell.scrolldatepicker.OnDateSelectedListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
public class CalendarActivity extends AppCompatActivity {
    Button plusButton;
    public static String selectedDate;
    DayScrollDatePicker dayDatePicker;
    boolean isDateSelected = false;
    private ListView displayListView;
    private List<String> taskNameList;
    private ArrayAdapter<String> textAdapter;
    private ArrayList<Task> taskArrayList;
    private ArrayList<Task> calender_taskArrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calendar_window);
        taskArrayList = new ArrayList<>();
        taskNameList = new ArrayList<>();
        calender_taskArrayList = new ArrayList<>();
        displayListView = findViewById(R.id.displayListView);
        retrieveAllDataFromFirebase();
        displayListView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedItem = textAdapter.getItem(position);
            Intent intent = new Intent(CalendarActivity.this, SelectedItemActivity.class);
            intent.putExtra("selectedItem", selectedItem);
            intent.putExtra("description", taskArrayList.get(position).getDescription());
            intent.putExtra("selectedImage", taskArrayList.get(position).getSelectedImageUrl());
            intent.putExtra("time",taskArrayList.get(position).getTime());
            intent.putExtra("recordPath",taskArrayList.get(position).getVoiceRecordePath());
            intent.putExtra("id",taskArrayList.get(position).getId());
            startActivity(intent);
        });
        plusButton = findViewById(R.id.plusButton);
        dayDatePicker = findViewById(R.id.dayDatePicker);
        dayDatePicker.getSelectedDate(new OnDateSelectedListener() {
            @Override
            public void onDateSelected(@Nullable Date date) {
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(date);
                    int year = calendar.get(Calendar.YEAR);
                    int month = calendar.get(Calendar.MONTH);
                    int day = calendar.get(Calendar.DAY_OF_MONTH);
                    selectedDate = year + month + day + "";
                    calender_taskArrayList.clear();
                    taskNameList.clear();
                    for(int i=0;i<taskArrayList.size();i++)
                    {
                        if(selectedDate.equals(taskArrayList.get(i).getDate()))
                        {
                            calender_taskArrayList.add(taskArrayList.get(i));
                        }
                    }
                    for(int i=0;i<calender_taskArrayList.size();i++)
                    {
                        taskNameList.add(calender_taskArrayList.get(i).getName());
                    }
                    textAdapter = new ArrayAdapter<>(CalendarActivity.this, android.R.layout.simple_list_item_1, taskNameList);
                    displayListView.setAdapter(textAdapter);
                    textAdapter.notifyDataSetChanged();
                    isDateSelected = true;
            }
        });

        plusButton.setOnClickListener(v -> {
            if (isDateSelected) {
                // Start the ClickableImageActivity
                Intent intent = new Intent(CalendarActivity.this, ClickableImageActivity.class);
                intent.putExtra("selectedDate",selectedDate);
                startActivity(intent);
            } else {
                Toast.makeText(CalendarActivity.this, "Please choose a date first", Toast.LENGTH_SHORT).show();
            }
        });
    }
    void retrieveAllDataFromFirebase(){
        ProgressDialog dialog = new ProgressDialog(CalendarActivity.this);
        dialog.show();
        dialog.setCancelable(false);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Tasks");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot snapshot1:snapshot.getChildren())
                {
                    Task task = snapshot1.getValue(Task.class);
                    if (task != null) {
                        taskNameList.add(task.getName());
                    }
                    taskArrayList.add(task);
                }
                textAdapter = new ArrayAdapter<>(CalendarActivity.this, android.R.layout.simple_list_item_1, taskNameList);
                displayListView.setAdapter(textAdapter);
                textAdapter.notifyDataSetChanged();
                dialog.dismiss();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                dialog.dismiss();
                Toast.makeText(CalendarActivity.this,"Error"+error.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }
}
