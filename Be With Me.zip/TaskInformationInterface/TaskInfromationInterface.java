package com.app.cardfeature7;

        import android.content.Context;
        import android.content.Intent;


        import android.net.Uri;
        import android.os.Bundle;
        import android.text.InputFilter;
        import android.view.View;
        import android.widget.AdapterView;
        import android.widget.ArrayAdapter;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.ImageView;
        import android.widget.Spinner;
        import android.widget.TextView;
        import android.widget.Toast;

        import androidx.appcompat.app.AppCompatActivity;

        import com.google.firebase.database.DatabaseReference;
        import com.google.firebase.database.FirebaseDatabase;
        import com.squareup.picasso.Picasso;

        import java.util.ArrayList;
        import java.util.List;
        import java.util.Locale;

public class TaskInfromationInterface extends AppCompatActivity implements AdapterView.OnItemSelectedListener, TimeSectionActivity.OnTimeSetListener {

    private TextView selectedTimeTextView;
    private TextView selectedvoice;
    private Button createTaskButton;
    private List<String> textList;
    private ArrayAdapter<String> textAdapter;
    private static final int GALLERY_REQUEST_CODE = 1;
    EditText editTextTaskName;
    EditText editTextTaskDescription;
    FirebaseDatabase database;
    DatabaseReference myRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clickable_image);
        Intent intent = getIntent();
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("Tasks");
        editTextTaskName = findViewById(R.id.editTextTaskName);
        editTextTaskDescription = findViewById(R.id.editTextDescription);
        Spinner dropdown = findViewById(R.id.dropdown);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dropdown.setAdapter(adapter);
        dropdown.setOnItemSelectedListener(this);
        ImageView clickableImage = findViewById(R.id.defaultImage);
        if(!MainActivity.selectedImagePath.isEmpty()) {
            Picasso.get().load(MainActivity.selectedImagePath).placeholder(R.drawable.playwhite).into(clickableImage);
        }
        selectedTimeTextView = findViewById(R.id.selectedTimeTextView);
        selectedvoice = findViewById(R.id.tvVoiceCreated);
        createTaskButton = findViewById(R.id.createTaskButton);
        textList = new ArrayList<>();
        textAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, textList);
        createTaskButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String taskName = editTextTaskName.getText().toString();
                String taskDescription = editTextTaskDescription.getText().toString();
                String selectedDate = CalendarInterface.selectedDate;
                String voiceRecordingPath = VoiceRecordActivity.path;
                String selectedImagePath = MainActivity.selectedImagePath;
                String id = myRef.push().getKey().toString();
                //Log.d("test123",CalendarActivity.selectedDate);
                if(validate(TaskInfromationInterface.this,selectedImagePath,taskName,selectedTimeTextView.getText().toString()))
                {
                    TaskContainer task = new TaskContainer(id,taskName,taskDescription,selectedImagePath,selectedDate,voiceRecordingPath,selectedTimeTextView.getText().toString());
                    myRef.child(id).setValue(task);
                    Intent intent1 = new Intent(TaskInfromationInterface.this, CalendarInterface.class);
                    startActivity(intent1);
                }

            }
        });
        clickableImage.setOnClickListener(v -> {
            // Start the MainActivity
            Intent intent1 = new Intent(TaskInfromationInterface.this, MainActivity.class);
            startActivity(intent1);
        });
        editTextTaskName = findViewById(R.id.editTextTaskName);
        editTextTaskName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});
    }

    static boolean validate(Context context,String image, String name, String time) {
        if(image.isEmpty())
        {
            Toast.makeText(context,"Select Image First",Toast.LENGTH_SHORT).show();
            return false;
        }
        if(name.isEmpty())
        {
            Toast.makeText(context,"Put Name First",Toast.LENGTH_SHORT).show();
            return false;
        }
        if(time.isEmpty())
        {
            Toast.makeText(context,"Select Time First",Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String selectedItem = parent.getItemAtPosition(position).toString();
        switch (selectedItem) {
            case "Voice Record":
                Intent voiceIntent = new Intent(TaskInfromationInterface.this, VoiceRecordActivity.class);
                startActivity(voiceIntent);
                break;
            case "Time Section":
                showTimePickerDialog();
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }
    private void showTimePickerDialog() {
        TimeSectionActivity timeSectionActivity = new TimeSectionActivity(this, 0, 0);
        timeSectionActivity.show(getSupportFragmentManager(), "time_picker");
    }
    @Override
    public void onTimeSet(int hourOfDay, int minute) {
        String formattedTime = String.format(Locale.getDefault(), "%02d:%02d", hourOfDay, minute);
        String displayText = "Selected time: " + formattedTime;
        selectedTimeTextView.setText(displayText);
        selectedTimeTextView.setVisibility(View.VISIBLE);
    }

    public void onRecordingFinished(int durationInSeconds) {
        int minutes = durationInSeconds / 60;
        int seconds = durationInSeconds % 60;
        String formattedTime = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
        String displayText = "Recorded time: " + formattedTime;
        selectedvoice.setText(displayText);
        selectedvoice.setVisibility(View.VISIBLE);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GALLERY_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            Uri selectedImage = data.getData();
            int position = data.getIntExtra("position", -1);
            if (position != -1) {
                Intent resultIntent = new Intent();
                resultIntent.putExtra("selectedImage", selectedImage);
                resultIntent.putExtra("position", position);
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        }
    }
}