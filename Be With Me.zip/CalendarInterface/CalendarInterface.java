package com.app.cardfeature7;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.harrywhewell.scrolldatepicker.DayScrollDatePicker;
import com.harrywhewell.scrolldatepicker.OnDateSelectedListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
public class CalendarInterface extends AppCompatActivity {
    Button plusButton;
    public static String selectedDate;
    DayScrollDatePicker dayDatePicker;
    boolean isDateSelected = false;
    private ListView displayListView;
    private List<String> taskNameList;
    private ArrayAdapter<String> textAdapter;
    private ArrayList<TaskContainer> taskContainerArrayList;
    private ArrayList<TaskContainer> calender_taskArrayListContainer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.calendar_window);
        taskContainerArrayList = new ArrayList<>();
        taskNameList = new ArrayList<>();
        calender_taskArrayListContainer = new ArrayList<>();
        displayListView = findViewById(R.id.displayListView);
        retrieveAllDataFromFirebase();
        displayListView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedItem = textAdapter.getItem(position);
            Intent intent = new Intent(CalendarInterface.this, SelectedItemActivity.class);
            intent.putExtra("selectedItem", selectedItem);
            intent.putExtra("description", taskContainerArrayList.get(position).getDescription());
            intent.putExtra("selectedImage", taskContainerArrayList.get(position).getSelectedImageUrl());
            intent.putExtra("time", taskContainerArrayList.get(position).getTime());
            intent.putExtra("recordPath", taskContainerArrayList.get(position).getVoiceRecordePath());
            intent.putExtra("id", taskContainerArrayList.get(position).getId());
            startActivity(intent);
        });
        plusButton = findViewById(R.id.plusButton);
        dayDatePicker = findViewById(R.id.dayDatePicker);
        dayDatePicker.getSelectedDate(new OnDateSelectedListener() {
            @Override
            public void onDateSelected(@Nullable Date date) {
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(date);
                    int year = calendar.get(Calendar.YEAR);
                    int month = calendar.get(Calendar.MONTH);
                    int day = calendar.get(Calendar.DAY_OF_MONTH);
                    selectedDate = year + month + day + "";
                    calender_taskArrayListContainer.clear();
                    taskNameList.clear();
                    for(int i = 0; i< taskContainerArrayList.size(); i++)
                    {
                        if(selectedDate.equals(taskContainerArrayList.get(i).getDate()))
                        {
                            calender_taskArrayListContainer.add(taskContainerArrayList.get(i));
                        }
                    }
                    for(int i = 0; i< calender_taskArrayListContainer.size(); i++)
                    {
                        taskNameList.add(calender_taskArrayListContainer.get(i).getName());
                    }
                    textAdapter = new ArrayAdapter<>(CalendarInterface.this, android.R.layout.simple_list_item_1, taskNameList);
                    displayListView.setAdapter(textAdapter);
                    textAdapter.notifyDataSetChanged();
                    isDateSelected = true;
            }
        });

        plusButton.setOnClickListener(v -> {
            if (isDateSelected) {
                // Start the ClickableImageActivity
                Intent intent = new Intent(CalendarInterface.this, TaskInfromationInterface.class);
                intent.putExtra("selectedDate",selectedDate);
                startActivity(intent);
            } else {
                Toast.makeText(CalendarInterface.this, "Please choose a date first", Toast.LENGTH_SHORT).show();
            }
        });
    }
    void retrieveAllDataFromFirebase(){
        ProgressDialog dialog = new ProgressDialog(CalendarInterface.this);
        dialog.show();
        dialog.setCancelable(false);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Tasks");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot snapshot1:snapshot.getChildren())
                {
                    TaskContainer taskContainer = snapshot1.getValue(TaskContainer.class);
                    if (taskContainer != null) {
                        taskNameList.add(taskContainer.getName());
                    }
                    taskContainerArrayList.add(taskContainer);
                }
                textAdapter = new ArrayAdapter<>(CalendarInterface.this, android.R.layout.simple_list_item_1, taskNameList);
                displayListView.setAdapter(textAdapter);
                textAdapter.notifyDataSetChanged();
                dialog.dismiss();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                dialog.dismiss();
                Toast.makeText(CalendarInterface.this,"Error"+error.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }
}
